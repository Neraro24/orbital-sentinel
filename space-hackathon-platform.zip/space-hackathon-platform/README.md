# Orbital Sentinel

Space-themed interactive hackathon platform with:

- 3D Earth + Moon orbital hub
- Live/predicted flood-climate-weather insights
- Age-gated experiences (Under 13 vs 13+)
- Moon first-person mode with 3 spaceship modules
- Multiplayer "find the imposter" room system
- Personal AI guide assistant

## Tech Stack

- Frontend: React + Vite + React Three Fiber + Socket.IO client
- Backend: Node.js + Express + Socket.IO
- Styling: Custom NASA-inspired CSS theme

## Quick Start

```bash
npm install
npm run dev
```

Frontend runs on `http://localhost:5173` and backend on `http://localhost:4000`.

## Project Structure

```text
space-hackathon-platform/
  client/   # React + 3D UI
  server/   # API + multiplayer sockets
```

## Feature Notes

- Climate data is mocked in backend and refreshed dynamically to simulate live + predicted feeds.
- AI assistant is rule-based by default (safe for demo). You can later swap it with an LLM provider.
- Multiplayer supports room code creation, joining, role assignment, and vote rounds.

## Future Enhancements

- Integrate live NOAA/NASA/ECMWF data feeds
- Add authentication and user profiles
- Add persistent game state and leaderboard
- Improve first-person world with GLTF models and audio
