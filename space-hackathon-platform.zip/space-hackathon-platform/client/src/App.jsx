import { useMemo, useState } from "react";
import AgeGate from "./components/AgeGate";
import TopNav from "./components/TopNav";
import SpaceHub from "./components/earth/SpaceHub";
import ClimateDashboard from "./components/dashboard/ClimateDashboard";
import EducationExperience from "./components/education/EducationExperience";
import MoonExperience from "./components/moon/MoonExperience";
import AIAssistant from "./components/ai/AIAssistant";
import { useClimateFeed } from "./hooks/useClimateFeed";

const AGE_STORAGE_KEY = "orbital-sentinel-age";

const getInitialAge = () => {
  const saved = window.localStorage.getItem(AGE_STORAGE_KEY);
  if (saved === "under13" || saved === "full") return saved;
  return null;
};

export default function App() {
  const [ageGroup, setAgeGroup] = useState(getInitialAge);
  const [selectedRegionId, setSelectedRegionId] = useState("bay-of-bengal");
  const [activeView, setActiveView] = useState("hub");
  const climate = useClimateFeed();

  const selectedRegion = useMemo(
    () => climate.regionMap.get(selectedRegionId) || climate.regions[0] || null,
    [climate.regionMap, climate.regions, selectedRegionId]
  );

  const chooseAgeGroup = (value) => {
    window.localStorage.setItem(AGE_STORAGE_KEY, value);
    setAgeGroup(value);
    setActiveView("hub");
  };

  const resetAge = () => {
    window.localStorage.removeItem(AGE_STORAGE_KEY);
    setAgeGroup(null);
  };

  if (!ageGroup) {
    return <AgeGate onSelect={chooseAgeGroup} />;
  }

  const under13 = ageGroup === "under13";

  return (
    <div className="app-shell">
      <TopNav
        ageGroup={ageGroup}
        activeView={activeView}
        onViewChange={setActiveView}
        onResetAge={resetAge}
        under13={under13}
      />

      <main className="main-content">
        {under13 ? (
          <section className="under13-layout">
            <EducationExperience />
            <ClimateDashboard
              regions={climate.regions}
              prediction={climate.prediction}
              selectedRegionId={selectedRegionId}
              onRegionSelect={setSelectedRegionId}
              loading={climate.loading}
              error={climate.error}
              updatedAt={climate.updatedAt}
              mode="educational"
            />
          </section>
        ) : (
          <>
            {activeView === "hub" ? (
              <section className="full-layout">
                <SpaceHub
                  regions={climate.regions}
                  selectedRegion={selectedRegion}
                  selectedRegionId={selectedRegionId}
                  onRegionSelect={setSelectedRegionId}
                  onMoonLaunch={() => setActiveView("moon")}
                />
                <ClimateDashboard
                  regions={climate.regions}
                  prediction={climate.prediction}
                  selectedRegionId={selectedRegionId}
                  onRegionSelect={setSelectedRegionId}
                  loading={climate.loading}
                  error={climate.error}
                  updatedAt={climate.updatedAt}
                  mode="full"
                />
              </section>
            ) : (
              <MoonExperience onBack={() => setActiveView("hub")} />
            )}
          </>
        )}
      </main>

      <AIAssistant ageGroup={ageGroup} selectedRegion={selectedRegion} />
    </div>
  );
}
