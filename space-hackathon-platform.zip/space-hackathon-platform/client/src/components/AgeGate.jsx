export default function AgeGate({ onSelect }) {
  return (
    <div className="age-gate">
      <div className="age-gate-card">
        <p className="eyebrow">Orbital Sentinel Access Control</p>
        <h1>Choose Mission Profile</h1>
        <p className="subtitle">
          The platform adapts to age for safe exploration. Under 13 gets Earth education mode. 13+ unlocks Moon missions and
          game modules.
        </p>
        <div className="age-options">
          <button className="option option-edu" onClick={() => onSelect("under13")}>
            <span>Under 13</span>
            <small>Earth learning only</small>
          </button>
          <button className="option option-full" onClick={() => onSelect("full")}>
            <span>13+</span>
            <small>Full Earth + Moon + games</small>
          </button>
        </div>
      </div>
      <div className="age-gate-backdrop" />
    </div>
  );
}
