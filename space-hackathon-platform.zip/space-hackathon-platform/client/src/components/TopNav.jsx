export default function TopNav({ ageGroup, activeView, onViewChange, onResetAge, under13 }) {
  return (
    <header className="top-nav">
      <div className="brand">
        <span className="brand-dot" />
        <div>
          <h2>Orbital Sentinel</h2>
          <p>NASA-style climate mission interface</p>
        </div>
      </div>

      <nav className="nav-actions">
        <button className={activeView === "hub" ? "active" : ""} onClick={() => onViewChange("hub")}>
          Earth Hub
        </button>
        {!under13 && (
          <button className={activeView === "moon" ? "active" : ""} onClick={() => onViewChange("moon")}>
            Moon Ops
          </button>
        )}
      </nav>

      <div className="profile-controls">
        <span className="age-pill">{ageGroup === "under13" ? "Educational Mode" : "Full Access"}</span>
        <button className="ghost" onClick={onResetAge}>
          Change Age Group
        </button>
      </div>
    </header>
  );
}
