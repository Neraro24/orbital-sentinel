import { useState } from "react";
import { askAssistant } from "../../services/api";

export default function AIAssistant({ ageGroup, selectedRegion }) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Mission AI online. Ask for navigation, climate explanations, or gameplay guidance."
    }
  ]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const text = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setLoading(true);
    try {
      const data = await askAssistant({
        message: text,
        ageGroup,
        region: selectedRegion?.label || null
      });
      setMessages((prev) => [...prev, { role: "assistant", content: data.response }]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: err.message || "Assistant channel unstable. Please retry."
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <aside className={`assistant ${open ? "open" : ""}`}>
      <button className="assistant-toggle" onClick={() => setOpen((v) => !v)}>
        AI Guide
      </button>
      {open && (
        <div className="assistant-panel">
          <h4>Personal Mission Assistant</h4>
          <div className="assistant-feed">
            {messages.map((msg, idx) => (
              <p key={idx} className={msg.role}>
                {msg.content}
              </p>
            ))}
          </div>
          <div className="assistant-input">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about floods, Moon mode, or gameplay..."
              onKeyDown={(e) => e.key === "Enter" && send()}
            />
            <button onClick={send} disabled={loading}>
              {loading ? "..." : "Send"}
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}
