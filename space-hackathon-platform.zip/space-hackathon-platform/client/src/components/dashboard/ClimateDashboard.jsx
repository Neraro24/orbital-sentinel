function riskTag(value) {
  if (value >= 70) return "risk high";
  if (value >= 40) return "risk medium";
  return "risk low";
}

export default function ClimateDashboard({
  regions,
  prediction,
  selectedRegionId,
  onRegionSelect,
  loading,
  error,
  updatedAt,
  mode
}) {
  return (
    <section className="dashboard-panel">
      <div className="dashboard-header">
        <div>
          <p className="eyebrow">{mode === "educational" ? "Earth Learning Data Console" : "Mission Control Data Console"}</p>
          <h3>Flood, Weather, and Climate Dashboard</h3>
        </div>
        <span className="updated">
          {loading ? "Syncing..." : `Updated: ${new Date(updatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`}
        </span>
      </div>

      {error && <p className="error-banner">{error}</p>}

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Region</th>
              <th>Temp (C)</th>
              <th>Flood Risk</th>
              <th>Humidity</th>
              <th>24h Risk</th>
              <th>Trend</th>
            </tr>
          </thead>
          <tbody>
            {regions.map((region) => {
              const pred = prediction.find((p) => p.id === region.id);
              return (
                <tr
                  key={region.id}
                  onClick={() => onRegionSelect(region.id)}
                  className={selectedRegionId === region.id ? "selected-row" : ""}
                >
                  <td>{region.label}</td>
                  <td>{region.temperature}</td>
                  <td>
                    <span className={riskTag(region.floodRisk)}>{region.floodRisk}%</span>
                  </td>
                  <td>{region.humidity}%</td>
                  <td>{pred?.prediction24h?.floodRisk ?? "--"}%</td>
                  <td>{region.trend}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
