import { Canvas, useFrame } from "@react-three/fiber";
import { Html, OrbitControls, Stars } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";

function latLonToVector3(lat, lon, radius = 1.42) {
  const phi = ((90 - lat) * Math.PI) / 180;
  const theta = ((lon + 180) * Math.PI) / 180;
  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
}

function Earth() {
  const earthRef = useRef(null);
  const cloudRef = useRef(null);

  useFrame(({ clock }) => {
    if (earthRef.current) earthRef.current.rotation.y = clock.getElapsedTime() * 0.09;
    if (cloudRef.current) cloudRef.current.rotation.y = -clock.getElapsedTime() * 0.05;
  });

  return (
    <group>
      <mesh ref={earthRef}>
        <sphereGeometry args={[1.35, 64, 64]} />
        <meshStandardMaterial color="#1e9fff" metalness={0.35} roughness={0.5} emissive="#02273f" emissiveIntensity={0.4} />
      </mesh>
      <mesh ref={cloudRef}>
        <sphereGeometry args={[1.41, 32, 32]} />
        <meshStandardMaterial color="#d9f6ff" transparent opacity={0.14} />
      </mesh>
      <mesh rotation={[Math.PI / 2.6, 0, 0]}>
        <torusGeometry args={[1.7, 0.03, 16, 120]} />
        <meshBasicMaterial color="#37c0ff" transparent opacity={0.35} />
      </mesh>
    </group>
  );
}

function RegionMarker({ region, selected, onSelect }) {
  const pos = useMemo(() => latLonToVector3(region.lat, region.lon), [region.lat, region.lon]);

  return (
    <group position={pos.toArray()}>
      <mesh onPointerDown={(e) => (e.stopPropagation(), onSelect(region.id))}>
        <sphereGeometry args={[selected ? 0.055 : 0.045, 12, 12]} />
        <meshBasicMaterial color={selected ? "#ffcb4b" : "#ff6f61"} />
      </mesh>
      {selected && (
        <>
          <mesh>
            <ringGeometry args={[0.07, 0.11, 24]} />
            <meshBasicMaterial color="#ffe082" side={THREE.DoubleSide} />
          </mesh>
          <Html distanceFactor={8}>
            <div className="marker-label">{region.label}</div>
          </Html>
        </>
      )}
    </group>
  );
}

function Moon({ onMoonLaunch }) {
  const moonRef = useRef(null);

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime() * 0.45;
    const radius = 3.4;
    if (moonRef.current) {
      moonRef.current.position.x = Math.cos(t) * radius;
      moonRef.current.position.z = Math.sin(t) * radius;
      moonRef.current.position.y = Math.sin(t * 0.6) * 0.4;
      moonRef.current.rotation.y += 0.004;
    }
  });

  return (
    <group ref={moonRef} onPointerDown={(e) => (e.stopPropagation(), onMoonLaunch())}>
      <mesh>
        <sphereGeometry args={[0.43, 48, 48]} />
        <meshStandardMaterial color="#c7c8cd" emissive="#5e6270" emissiveIntensity={0.2} roughness={0.8} />
      </mesh>
      <mesh>
        <ringGeometry args={[0.54, 0.58, 40]} />
        <meshBasicMaterial color="#fff9c4" transparent opacity={0.6} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

export default function OrbitalScene({ regions, selectedRegionId, onRegionSelect, onMoonLaunch }) {
  return (
    <Canvas camera={{ position: [0, 0.2, 6], fov: 55 }}>
      <color attach="background" args={["#04091a"]} />
      <fog attach="fog" args={["#04091a", 7, 12]} />
      <ambientLight intensity={0.65} />
      <directionalLight position={[4, 2, 3]} intensity={1.1} color="#dce8ff" />
      <pointLight position={[-3, -2, -4]} intensity={0.75} color="#6ac8ff" />
      <Stars radius={80} depth={60} factor={3} saturation={0} fade speed={0.35} />

      <Earth />
      <Moon onMoonLaunch={onMoonLaunch} />
      {regions.map((region) => (
        <RegionMarker key={region.id} region={region} selected={region.id === selectedRegionId} onSelect={onRegionSelect} />
      ))}

      <OrbitControls enablePan={false} minDistance={3.5} maxDistance={9} />
    </Canvas>
  );
}
