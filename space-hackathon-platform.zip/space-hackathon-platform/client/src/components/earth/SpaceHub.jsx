import OrbitalScene from "./OrbitalScene";

function metricClass(risk) {
  if (risk >= 70) return "danger";
  if (risk >= 40) return "warn";
  return "safe";
}

export default function SpaceHub({ regions, selectedRegion, selectedRegionId, onRegionSelect, onMoonLaunch }) {
  return (
    <section className="hub-panel">
      <div className="hub-visual">
        <OrbitalScene
          regions={regions}
          selectedRegionId={selectedRegionId}
          onRegionSelect={onRegionSelect}
          onMoonLaunch={onMoonLaunch}
        />
      </div>

      <aside className="hub-insights">
        <p className="eyebrow">Planetary Insights</p>
        <h3>Earth Live Monitoring</h3>
        {selectedRegion ? (
          <div className="region-insight-card">
            <h4>{selectedRegion.label}</h4>
            <p>{selectedRegion.trend}</p>
            <div className="insight-metrics">
              <div>
                <span>Temp</span>
                <strong>{selectedRegion.temperature}C</strong>
              </div>
              <div>
                <span>Humidity</span>
                <strong>{selectedRegion.humidity}%</strong>
              </div>
              <div className={metricClass(selectedRegion.floodRisk)}>
                <span>Flood Risk</span>
                <strong>{selectedRegion.floodRisk}%</strong>
              </div>
            </div>
            <div className="prediction-chip">
              <span>24h Prediction</span>
              <strong>{selectedRegion.prediction24h?.floodRisk ?? "--"}%</strong>
            </div>
            <p className="hint">{selectedRegion.prediction24h?.warning}</p>
          </div>
        ) : (
          <p>Loading region insight...</p>
        )}

        <button className="launch-button" onClick={onMoonLaunch}>
          Launch Moon First-Person Mode
        </button>
      </aside>
    </section>
  );
}
