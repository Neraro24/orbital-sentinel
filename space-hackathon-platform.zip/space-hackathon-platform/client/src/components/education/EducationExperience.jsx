import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useEffect, useState } from "react";
import { fetchEducationModules } from "../../services/api";

function LayeredEarth() {
  useFrame((state) => {
    state.scene.rotation.y = state.clock.getElapsedTime() * 0.12;
  });

  return (
    <group>
      <mesh>
        <sphereGeometry args={[1.1, 32, 32]} />
        <meshStandardMaterial color="#2e9fff" transparent opacity={0.6} />
      </mesh>
      <mesh>
        <sphereGeometry args={[0.75, 32, 32]} />
        <meshStandardMaterial color="#f59f00" transparent opacity={0.75} />
      </mesh>
      <mesh>
        <sphereGeometry args={[0.35, 32, 32]} />
        <meshStandardMaterial color="#ff6b6b" emissive="#8a0f18" emissiveIntensity={0.25} />
      </mesh>
    </group>
  );
}

export default function EducationExperience() {
  const [modules, setModules] = useState([]);

  useEffect(() => {
    fetchEducationModules()
      .then((data) => setModules(data.modules || []))
      .catch(() => setModules([]));
  }, []);

  return (
    <section className="education-panel">
      <div>
        <p className="eyebrow">Under 13 Educational Mode</p>
        <h3>Earth Through Time</h3>
      </div>

      <div className="education-grid">
        <div className="eras-card">
          <h4>Geological Eras Explorer</h4>
          {modules.map((module) => (
            <article key={module.id}>
              <strong>{module.title}</strong>
              <p>{module.era}</p>
              <small>{module.detail}</small>
            </article>
          ))}
        </div>

        <div className="layers-card">
          <h4>Earth Internal Layers (3D)</h4>
          <div className="layer-canvas">
            <Canvas camera={{ position: [0, 0, 3.2], fov: 55 }}>
              <ambientLight intensity={0.75} />
              <directionalLight position={[2, 2, 3]} intensity={0.9} />
              <LayeredEarth />
              <OrbitControls enablePan={false} />
            </Canvas>
          </div>
          <p>Crust, mantle, and core are visualized as concentric rotating shells for easy learning.</p>
        </div>
      </div>
    </section>
  );
}
