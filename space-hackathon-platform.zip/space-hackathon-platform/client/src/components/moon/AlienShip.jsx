import { useMemo, useState } from "react";

const randomCode = () => String(Math.floor(1000 + Math.random() * 9000));

export default function AlienShip() {
  const [health, setHealth] = useState(100);
  const [alienHealth, setAlienHealth] = useState(120);
  const [killswitch, setKillswitch] = useState(randomCode);
  const [hint, setHint] = useState("");
  const [guess, setGuess] = useState("");
  const [log, setLog] = useState(["Mission started. Survive and find the kill code."]);
  const [ended, setEnded] = useState(false);

  const state = useMemo(() => {
    if (ended && health > 0) return "escaped";
    if (health <= 0) return "failed";
    return "active";
  }, [ended, health]);

  const pushLog = (text) => setLog((prev) => [text, ...prev].slice(0, 8));

  const attack = () => {
    if (state !== "active") return;
    const damage = Math.round(14 + Math.random() * 16);
    const retaliation = Math.round(8 + Math.random() * 18);
    setAlienHealth((prev) => Math.max(0, prev - damage));
    setHealth((prev) => Math.max(0, prev - retaliation));
    pushLog(`You deal ${damage} damage. Alien retaliates for ${retaliation}.`);
  };

  const scan = () => {
    if (state !== "active") return;
    const idx = Math.floor(Math.random() * 4);
    setHint(`Digit #${idx + 1} is ${killswitch[idx]}`);
    const retaliation = Math.round(5 + Math.random() * 12);
    setHealth((prev) => Math.max(0, prev - retaliation));
    pushLog(`Scan reveals a clue, but alarm drains ${retaliation} health.`);
  };

  const submitCode = () => {
    if (state !== "active") return;
    if (guess === killswitch) {
      setEnded(true);
      pushLog("Kill code accepted. Escape pod launch success.");
      return;
    }
    const retaliation = Math.round(10 + Math.random() * 14);
    setHealth((prev) => Math.max(0, prev - retaliation));
    pushLog(`Wrong code. Security burst hits you for ${retaliation}.`);
  };

  const restart = () => {
    setHealth(100);
    setAlienHealth(120);
    setKillswitch(randomCode());
    setHint("");
    setGuess("");
    setEnded(false);
    setLog(["Mission restarted."]);
  };

  return (
    <div className="module-shell">
      <div className="module-header">
        <h3>Alien Spaceship Escape Mission</h3>
        <p>Fight aliens, gather code clues, and enter the kill code before your suit fails.</p>
      </div>

      <div className="alien-grid">
        <div className="battle-card">
          <h4>Combat Status</h4>
          <p>
            Astronaut Health: <strong>{health}</strong>
          </p>
          <p>
            Alien Threat: <strong>{alienHealth}</strong>
          </p>
          <div className="row-buttons">
            <button onClick={attack} disabled={state !== "active"}>
              Attack
            </button>
            <button onClick={scan} disabled={state !== "active"}>
              Scan for Clue
            </button>
          </div>
        </div>

        <div className="code-card">
          <h4>Kill Code Console</h4>
          <p className="hint">{hint || "Scan systems to reveal kill code digits."}</p>
          <input value={guess} onChange={(e) => setGuess(e.target.value)} maxLength={4} placeholder="Enter 4-digit code" />
          <div className="row-buttons">
            <button onClick={submitCode} disabled={state !== "active"}>
              Submit Code
            </button>
            <button className="ghost" onClick={restart}>
              Restart
            </button>
          </div>
          {state === "escaped" && <p className="safe">Mission success. You escaped the alien ship.</p>}
          {state === "failed" && <p className="danger">Suit integrity failed. Mission lost.</p>}
        </div>

        <div className="mission-log">
          <h4>Mission Log</h4>
          <ul>
            {log.map((item, i) => (
              <li key={i}>{item}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
