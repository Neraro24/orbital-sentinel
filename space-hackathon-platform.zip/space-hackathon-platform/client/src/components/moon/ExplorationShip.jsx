import { useEffect, useRef, useState } from "react";

const parts = [
  { name: "Observation Dome", detail: "Panoramic shielded viewport for Earth imaging and terrain scans." },
  { name: "Life Support Core", detail: "Regulates oxygen, pressure, and humidity for long missions." },
  { name: "Orbital Relay Unit", detail: "Transmits geospatial climate snapshots to mission control." },
  { name: "Sample Bay", detail: "Stores lunar dust and rock cores for educational analysis." }
];

function drawEarthView(canvas) {
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  ctx.fillStyle = "#060c1c";
  ctx.fillRect(0, 0, w, h);

  for (let i = 0; i < 120; i += 1) {
    ctx.fillStyle = "rgba(255,255,255,0.8)";
    ctx.fillRect(Math.random() * w, Math.random() * h, 1.2, 1.2);
  }

  const gradient = ctx.createRadialGradient(w * 0.68, h * 0.45, 10, w * 0.68, h * 0.45, 120);
  gradient.addColorStop(0, "#66d2ff");
  gradient.addColorStop(0.65, "#1d92ff");
  gradient.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(w * 0.68, h * 0.45, 105, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "rgba(30,200,120,0.7)";
  ctx.beginPath();
  ctx.ellipse(w * 0.68, h * 0.45, 65, 30, 0.8, 0, Math.PI * 2);
  ctx.fill();
}

export default function ExplorationShip() {
  const canvasRef = useRef(null);
  const [shots, setShots] = useState([]);
  const [activePart, setActivePart] = useState(parts[0]);

  useEffect(() => {
    if (canvasRef.current) drawEarthView(canvasRef.current);
  }, []);

  const capture = () => {
    if (!canvasRef.current) return;
    setShots((prev) => [canvasRef.current.toDataURL("image/png"), ...prev].slice(0, 6));
  };

  return (
    <div className="module-shell">
      <div className="module-header">
        <h3>Exploration Spaceship</h3>
        <p>Capture Earth photos from Moon and explore spacecraft components for learning.</p>
      </div>

      <div className="exploration-grid">
        <div className="earth-camera">
          <h4>Earth View Camera</h4>
          <canvas ref={canvasRef} width={480} height={280} />
          <button onClick={capture}>Capture Image</button>
          <div className="shot-strip">
            {shots.length === 0 ? <p>No photos yet.</p> : shots.map((src, idx) => <img key={idx} src={src} alt={`Earth shot ${idx + 1}`} />)}
          </div>
        </div>

        <div className="ship-parts">
          <h4>Ship Parts Explorer</h4>
          <div className="parts-list">
            {parts.map((part) => (
              <button key={part.name} className={activePart.name === part.name ? "active" : ""} onClick={() => setActivePart(part)}>
                {part.name}
              </button>
            ))}
          </div>
          <article>
            <h5>{activePart.name}</h5>
            <p>{activePart.detail}</p>
          </article>
        </div>
      </div>
    </div>
  );
}
