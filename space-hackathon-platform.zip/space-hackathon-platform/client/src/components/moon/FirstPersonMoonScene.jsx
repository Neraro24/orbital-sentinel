import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Html, Stars } from "@react-three/drei";
import { useEffect, useRef } from "react";
import * as THREE from "three";

const ships = [
  { id: "exploration", label: "Exploration Ship", position: [-6, 1, -4], color: "#40c4ff" },
  { id: "multiplayer", label: "Multiplayer Ship", position: [0, 1, -8], color: "#ffd54f" },
  { id: "alien", label: "Alien Ship", position: [6, 1, -4], color: "#ff6e6e" }
];

function PilotController() {
  const { camera } = useThree();
  const keysRef = useRef({ w: false, a: false, s: false, d: false });

  useEffect(() => {
    const down = (e) => {
      const key = e.key.toLowerCase();
      if (key in keysRef.current) keysRef.current[key] = true;
    };
    const up = (e) => {
      const key = e.key.toLowerCase();
      if (key in keysRef.current) keysRef.current[key] = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useFrame((_, delta) => {
    const speed = 3.4 * delta;
    const dir = new THREE.Vector3();
    camera.getWorldDirection(dir);
    dir.y = 0;
    dir.normalize();
    const right = new THREE.Vector3().crossVectors(dir, new THREE.Vector3(0, 1, 0)).normalize();

    if (keysRef.current.w) camera.position.addScaledVector(dir, speed);
    if (keysRef.current.s) camera.position.addScaledVector(dir, -speed);
    if (keysRef.current.a) camera.position.addScaledVector(right, speed);
    if (keysRef.current.d) camera.position.addScaledVector(right, -speed);

    camera.position.y = 1.45;
    camera.lookAt(0, 1.1, -6);
  });

  return null;
}

function MoonSurface() {
  return (
    <>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[80, 80]} />
        <meshStandardMaterial color="#7f8087" roughness={1} />
      </mesh>
      {Array.from({ length: 40 }).map((_, i) => (
        <mesh key={i} position={[Math.random() * 50 - 25, 0.2, Math.random() * 50 - 25]} castShadow>
          <dodecahedronGeometry args={[Math.random() * 0.28 + 0.12, 0]} />
          <meshStandardMaterial color="#8d8e96" roughness={1} />
        </mesh>
      ))}
    </>
  );
}

function ShipBeacon({ ship, onDock }) {
  return (
    <group position={ship.position}>
      <mesh onPointerDown={(e) => (e.stopPropagation(), onDock(ship.id))}>
        <boxGeometry args={[1.7, 1.15, 3]} />
        <meshStandardMaterial color={ship.color} emissive={ship.color} emissiveIntensity={0.45} />
      </mesh>
      <mesh position={[0, 0.7, 0]}>
        <ringGeometry args={[1.3, 1.5, 32]} />
        <meshBasicMaterial color={ship.color} />
      </mesh>
      <Html position={[0, 1.7, 0]} distanceFactor={12}>
        <div className="ship-label">{ship.label}</div>
      </Html>
    </group>
  );
}

export default function FirstPersonMoonScene({ onDock }) {
  return (
    <div className="moon-canvas-wrap">
      <Canvas camera={{ position: [0, 1.45, 4], fov: 65 }} shadows>
        <color attach="background" args={["#06080f"]} />
        <fog attach="fog" args={["#06080f", 18, 60]} />
        <ambientLight intensity={0.55} />
        <directionalLight position={[4, 8, 2]} intensity={1} castShadow />
        <pointLight position={[-4, 5, -8]} intensity={0.8} color="#8ed3ff" />
        <Stars radius={130} depth={80} count={5000} factor={3} fade speed={0.5} />
        <PilotController />
        <MoonSurface />
        {ships.map((ship) => (
          <ShipBeacon key={ship.id} ship={ship} onDock={onDock} />
        ))}
      </Canvas>
    </div>
  );
}
