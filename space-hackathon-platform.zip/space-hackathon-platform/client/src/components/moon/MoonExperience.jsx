import { useState } from "react";
import FirstPersonMoonScene from "./FirstPersonMoonScene";
import ExplorationShip from "./ExplorationShip";
import MultiplayerShip from "./MultiplayerShip";
import AlienShip from "./AlienShip";

function moduleLabel(activeModule) {
  if (activeModule === "exploration") return "Exploration spaceship docked";
  if (activeModule === "multiplayer") return "Multiplayer spaceship docked";
  if (activeModule === "alien") return "Alien spaceship docked";
  return "Free walk on Moon surface";
}

export default function MoonExperience({ onBack }) {
  const [activeModule, setActiveModule] = useState("");

  return (
    <section className="moon-layout">
      <div className="moon-topbar">
        <button className="ghost" onClick={onBack}>
          Return to Earth Hub
        </button>
        <p>{moduleLabel(activeModule)}</p>
      </div>

      <div className="moon-main">
        <div className="moon-left">
          <FirstPersonMoonScene onDock={setActiveModule} />
          <p className="controls-hint">
            Move with WASD. Click a glowing ship to open its mission console. Moon mode is available only for 13+ access.
          </p>
        </div>

        <div className="moon-right">
          {!activeModule && (
            <div className="module-shell">
              <div className="module-header">
                <h3>Moon Operations Console</h3>
                <p>Select a spaceship beacon from the scene to begin a module.</p>
              </div>
              <ul className="module-list">
                <li>
                  <strong>Exploration Ship</strong>: Earth photo capture + educational parts walkthrough
                </li>
                <li>
                  <strong>Multiplayer Ship</strong>: Code-based social deduction room
                </li>
                <li>
                  <strong>Alien Ship</strong>: Single-player combat and kill-code escape
                </li>
              </ul>
            </div>
          )}
          {activeModule === "exploration" && <ExplorationShip />}
          {activeModule === "multiplayer" && <MultiplayerShip />}
          {activeModule === "alien" && <AlienShip />}
        </div>
      </div>
    </section>
  );
}
