import { useEffect, useMemo, useRef, useState } from "react";
import { io } from "socket.io-client";

export default function MultiplayerShip() {
  const socketRef = useRef(null);
  const [name, setName] = useState("");
  const [roomCodeInput, setRoomCodeInput] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [playerId, setPlayerId] = useState("");
  const [room, setRoom] = useState(null);
  const [role, setRole] = useState("crew");
  const [status, setStatus] = useState("Connect and create or join a room.");

  useEffect(() => {
    const socket = io(import.meta.env.VITE_SOCKET_URL || "/", { transports: ["websocket", "polling"] });
    socketRef.current = socket;

    socket.on("room:joined", ({ code, playerId: pid }) => {
      setRoomCode(code);
      setPlayerId(pid);
      setStatus(`Joined room ${code}. Waiting for host to start.`);
    });

    socket.on("room:update", (roomState) => {
      setRoom(roomState);
      if (roomState.phase === "lobby") setStatus(`Room ${roomState.code} is in lobby.`);
      if (roomState.phase === "in-game") setStatus("Game active. Discuss and vote the imposter.");
      if (roomState.phase === "finished") setStatus(`Game over. Winner: ${roomState.winner}`);
    });

    socket.on("game:role", (assignedRole) => {
      setRole(assignedRole);
    });

    socket.on("game:roundResult", ({ eliminatedId, room: roomState }) => {
      const eliminated = roomState.players.find((p) => p.id === eliminatedId);
      const eliminatedName = eliminated ? eliminated.name : "No one";
      setStatus(`Round result: ${eliminatedName} eliminated.`);
      setRoom(roomState);
    });

    socket.on("room:error", (msg) => {
      setStatus(msg);
    });

    return () => socket.disconnect();
  }, []);

  const me = useMemo(() => room?.players?.find((p) => p.id === playerId), [room, playerId]);
  const isHost = Boolean(me?.isHost);

  const createRoom = () => {
    if (!name.trim()) return setStatus("Enter your astronaut name first.");
    socketRef.current?.emit("room:create", { name });
  };

  const joinRoom = () => {
    if (!name.trim()) return setStatus("Enter your astronaut name first.");
    if (!roomCodeInput.trim()) return setStatus("Enter a room code.");
    socketRef.current?.emit("room:join", { code: roomCodeInput.trim().toUpperCase(), name });
  };

  const startGame = () => socketRef.current?.emit("game:start", { code: roomCode });
  const vote = (targetId) => socketRef.current?.emit("game:vote", { code: roomCode, targetId });

  return (
    <div className="module-shell">
      <div className="module-header">
        <h3>Multiplayer Spaceship</h3>
        <p>Code-based social deduction mission inspired by imposter gameplay.</p>
      </div>

      <div className="multiplayer-grid">
        <div className="room-controls">
          <label>
            Astronaut Name
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Commander Nova" />
          </label>
          <div className="row-buttons">
            <button onClick={createRoom}>Create Room</button>
          </div>
          <label>
            Join by Code
            <input value={roomCodeInput} onChange={(e) => setRoomCodeInput(e.target.value)} placeholder="ABC123" />
          </label>
          <button onClick={joinRoom}>Join Room</button>
          <p className="status">{status}</p>
          {roomCode && <p className="room-code">Active Room: {roomCode}</p>}
        </div>

        <div className="room-state">
          <h4>Mission Room State</h4>
          <p>
            Your role: <strong className={role === "imposter" ? "danger" : "safe"}>{role.toUpperCase()}</strong>
          </p>
          {room ? (
            <>
              <ul className="player-list">
                {room.players.map((player) => (
                  <li key={player.id} className={!player.alive ? "eliminated" : ""}>
                    {player.name} {player.isHost ? "(Host)" : ""} {!player.alive ? "- Eliminated" : ""}
                    {room.phase === "in-game" && me?.alive && player.alive && player.id !== playerId && (
                      <button onClick={() => vote(player.id)}>Vote</button>
                    )}
                  </li>
                ))}
              </ul>
              {room.phase === "lobby" && isHost && (
                <button className="launch-button" onClick={startGame}>
                  Start Mission
                </button>
              )}
            </>
          ) : (
            <p>No active room yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
