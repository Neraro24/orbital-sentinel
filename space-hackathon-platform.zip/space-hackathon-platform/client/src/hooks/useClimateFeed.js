import { useEffect, useMemo, useState } from "react";
import { fetchClimatePrediction, fetchLiveClimate } from "../services/api";

const REFRESH_MS = 15000;

export function useClimateFeed() {
  const [regions, setRegions] = useState([]);
  const [prediction, setPrediction] = useState([]);
  const [updatedAt, setUpdatedAt] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;

    async function loadClimate() {
      try {
        const [live, pred] = await Promise.all([fetchLiveClimate(), fetchClimatePrediction()]);
        if (!mounted) return;
        setRegions(live.regions || []);
        setPrediction(pred.regions || []);
        setUpdatedAt(live.updatedAt || new Date().toISOString());
        setError("");
      } catch (err) {
        if (!mounted) return;
        setError(err.message || "Could not fetch climate feed");
      } finally {
        if (mounted) setLoading(false);
      }
    }

    loadClimate();
    const timer = setInterval(loadClimate, REFRESH_MS);
    return () => {
      mounted = false;
      clearInterval(timer);
    };
  }, []);

  const regionMap = useMemo(() => {
    const map = new Map();
    regions.forEach((region) => map.set(region.id, region));
    return map;
  }, [regions]);

  return {
    regions,
    prediction,
    regionMap,
    updatedAt,
    loading,
    error
  };
}
