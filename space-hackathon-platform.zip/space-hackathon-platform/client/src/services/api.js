const jsonHeaders = {
  "Content-Type": "application/json"
};
const API_BASE = import.meta.env.VITE_API_BASE || "/api";

export async function fetchLiveClimate() {
  const res = await fetch(`${API_BASE}/climate/live`);
  if (!res.ok) throw new Error("Failed to load live climate data");
  return res.json();
}

export async function fetchClimatePrediction() {
  const res = await fetch(`${API_BASE}/climate/prediction`);
  if (!res.ok) throw new Error("Failed to load climate prediction");
  return res.json();
}

export async function fetchEducationModules() {
  const res = await fetch(`${API_BASE}/education/modules`);
  if (!res.ok) throw new Error("Failed to load education modules");
  return res.json();
}

export async function askAssistant(payload) {
  const res = await fetch(`${API_BASE}/assistant`, {
    method: "POST",
    headers: jsonHeaders,
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error("Assistant is currently offline");
  return res.json();
}
