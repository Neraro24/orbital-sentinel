import http from "node:http";
import express from "express";
import cors from "cors";
import { customAlphabet } from "nanoid";
import { Server } from "socket.io";

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const roomCodeId = customAlphabet("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", 6);

const baseClimateProfiles = [
  {
    id: "bay-of-bengal",
    label: "Bay of Bengal",
    lat: 14.6,
    lon: 88.3,
    tempBase: 30.8,
    floodRiskBase: 71,
    trend: "Rising cyclone intensity"
  },
  {
    id: "california",
    label: "California Coast",
    lat: 36.7,
    lon: -121.9,
    tempBase: 24.4,
    floodRiskBase: 49,
    trend: "Storm surge volatility"
  },
  {
    id: "netherlands",
    label: "Netherlands Delta",
    lat: 52,
    lon: 4.3,
    tempBase: 18.3,
    floodRiskBase: 58,
    trend: "Sea level adaptation pressure"
  },
  {
    id: "east-africa",
    label: "East Africa",
    lat: -3.3,
    lon: 39.7,
    tempBase: 27.1,
    floodRiskBase: 62,
    trend: "Extreme rain bursts"
  },
  {
    id: "arctic",
    label: "Arctic Circle",
    lat: 72.5,
    lon: -42.3,
    tempBase: -9.2,
    floodRiskBase: 18,
    trend: "Rapid ice melt trend"
  }
];

const addNoise = (value, spread) => Number((value + (Math.random() * spread - spread / 2)).toFixed(2));

const buildLiveData = () =>
  baseClimateProfiles.map((profile) => {
    const temperature = addNoise(profile.tempBase, 4.6);
    const floodRisk = Math.max(1, Math.min(100, Math.round(addNoise(profile.floodRiskBase, 22))));
    const humidity = Math.max(10, Math.min(99, Math.round(addNoise(66, 20))));
    const anomaly = Number((temperature - profile.tempBase).toFixed(2));
    const riskLevel = floodRisk > 70 ? "HIGH" : floodRisk > 40 ? "MEDIUM" : "LOW";
    const confidence = Math.round(addNoise(85, 15));

    return {
      ...profile,
      timestamp: new Date().toISOString(),
      temperature,
      floodRisk,
      humidity,
      anomaly,
      riskLevel,
      confidence,
      prediction24h: {
        floodRisk: Math.max(1, Math.min(100, floodRisk + Math.round(addNoise(3, 12)))),
        temperature: Number((temperature + addNoise(0.8, 2.4)).toFixed(2)),
        warning: floodRisk > 68 ? "Potential urban flooding in low-lying zones" : "No severe flood warning in next 24 hours"
      }
    };
  });

const educationModules = [
  {
    id: "era-hadean",
    title: "Hadean Earth",
    era: "4.6-4.0 billion years ago",
    detail: "Molten surface, heavy bombardment, and first crust formation."
  },
  {
    id: "era-archean",
    title: "Archean Earth",
    era: "4.0-2.5 billion years ago",
    detail: "Stable crust appears, oceans deepen, first microbial life emerges."
  },
  {
    id: "era-proterozoic",
    title: "Proterozoic Earth",
    era: "2.5 billion-541 million years ago",
    detail: "Oxygenation events and early multicellular organisms reshape the planet."
  }
];

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "orbital-sentinel-api", timestamp: new Date().toISOString() });
});

app.get("/api/climate/live", (_req, res) => {
  res.json({ updatedAt: new Date().toISOString(), regions: buildLiveData() });
});

app.get("/api/climate/prediction", (_req, res) => {
  const regions = buildLiveData().map((region) => ({
    id: region.id,
    label: region.label,
    trend: region.trend,
    confidence: region.confidence,
    prediction24h: region.prediction24h
  }));
  res.json({ updatedAt: new Date().toISOString(), regions });
});

app.get("/api/education/modules", (_req, res) => {
  res.json({ modules: educationModules });
});

app.post("/api/assistant", (req, res) => {
  const message = String(req.body?.message || "").toLowerCase();
  const ageGroup = req.body?.ageGroup === "under13" ? "under13" : "full";

  let reply = "I can guide you through Earth data, Moon missions, and climate alerts. Ask me what to explore next.";

  if (message.includes("flood")) {
    reply = "Flood risk blends rainfall, soil saturation, and tide surge. Click any highlighted region to inspect current and 24h predicted risk.";
  } else if (message.includes("moon")) {
    reply =
      ageGroup === "under13"
        ? "Moon missions are disabled in learning mode. Try Earth layers and geological era explorer for your age group."
        : "In Moon mode, walk to a spaceship beacon to launch Exploration, Multiplayer, or Alien Mission modules.";
  } else if (message.includes("temperature") || message.includes("climate")) {
    reply = "The dashboard compares live temperature anomaly and forecasted trend. Higher anomaly + high humidity can amplify extreme weather risk.";
  } else if (message.includes("help")) {
    reply =
      ageGroup === "under13"
        ? "Start with Earth eras, then inspect internal layers and climate table. I can explain each part step-by-step."
        : "Try this flow: Earth region insight -> Moon landing -> Exploration ship -> Multiplayer room.";
  }

  res.json({
    response: reply,
    timestamp: new Date().toISOString()
  });
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*"
  }
});

const rooms = new Map();

const toPublicRoom = (room) => ({
  code: room.code,
  phase: room.phase,
  winner: room.winner,
  players: [...room.players.values()].map((p) => ({
    id: p.id,
    name: p.name,
    isHost: p.isHost,
    alive: p.alive
  }))
});

const emitRoom = (code) => {
  const room = rooms.get(code);
  if (!room) return;
  io.to(code).emit("room:update", toPublicRoom(room));
};

const evaluateGameStatus = (room) => {
  const aliveCrew = [...room.players.values()].filter((p) => p.alive && p.role !== "imposter");
  const aliveImposter = [...room.players.values()].filter((p) => p.alive && p.role === "imposter");

  if (aliveImposter.length === 0) {
    room.phase = "finished";
    room.winner = "crew";
  } else if (aliveCrew.length <= 1) {
    room.phase = "finished";
    room.winner = "imposter";
  }
};

io.on("connection", (socket) => {
  socket.on("room:create", ({ name }) => {
    const cleanName = String(name || "Astronaut").trim().slice(0, 18) || "Astronaut";
    const code = roomCodeId();
    const player = {
      id: socket.id,
      name: cleanName,
      isHost: true,
      role: "crew",
      alive: true,
      hasVoted: false
    };
    rooms.set(code, {
      code,
      phase: "lobby",
      winner: null,
      players: new Map([[socket.id, player]]),
      votes: {}
    });
    socket.join(code);
    socket.emit("room:joined", { code, playerId: socket.id });
    emitRoom(code);
  });

  socket.on("room:join", ({ code, name }) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room) {
      socket.emit("room:error", "Room not found");
      return;
    }
    if (room.phase !== "lobby") {
      socket.emit("room:error", "Game has already started");
      return;
    }
    const cleanName = String(name || "Astronaut").trim().slice(0, 18) || "Astronaut";
    room.players.set(socket.id, {
      id: socket.id,
      name: cleanName,
      isHost: false,
      role: "crew",
      alive: true,
      hasVoted: false
    });
    socket.join(room.code);
    socket.emit("room:joined", { code: room.code, playerId: socket.id });
    emitRoom(room.code);
  });

  socket.on("game:start", ({ code }) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room) return;
    if (room.players.size < 3) {
      socket.emit("room:error", "At least 3 players required to start");
      return;
    }

    room.phase = "in-game";
    room.winner = null;
    room.votes = {};
    const players = [...room.players.values()];
    players.forEach((p) => {
      p.alive = true;
      p.hasVoted = false;
      p.role = "crew";
    });
    const imposter = players[Math.floor(Math.random() * players.length)];
    imposter.role = "imposter";

    players.forEach((p) => {
      io.to(p.id).emit("game:role", p.role);
    });
    emitRoom(room.code);
  });

  socket.on("game:vote", ({ code, targetId }) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room || room.phase !== "in-game") return;

    const voter = room.players.get(socket.id);
    if (!voter || !voter.alive || voter.hasVoted) return;
    const target = room.players.get(targetId);
    if (!target || !target.alive) return;

    voter.hasVoted = true;
    room.votes[targetId] = (room.votes[targetId] || 0) + 1;

    const alivePlayers = [...room.players.values()].filter((p) => p.alive);
    const votedCount = alivePlayers.filter((p) => p.hasVoted).length;

    if (votedCount === alivePlayers.length) {
      const [eliminatedId] = Object.entries(room.votes).sort((a, b) => b[1] - a[1])[0] || [];
      if (eliminatedId && room.players.has(eliminatedId)) {
        room.players.get(eliminatedId).alive = false;
      }
      room.votes = {};
      room.players.forEach((p) => {
        if (p.alive) p.hasVoted = false;
      });

      evaluateGameStatus(room);
      io.to(room.code).emit("game:roundResult", { eliminatedId: eliminatedId || null, room: toPublicRoom(room) });
    }

    emitRoom(room.code);
  });

  socket.on("disconnect", () => {
    rooms.forEach((room, code) => {
      if (!room.players.has(socket.id)) return;
      const leaving = room.players.get(socket.id);
      room.players.delete(socket.id);

      if (room.players.size === 0) {
        rooms.delete(code);
        return;
      }

      if (leaving?.isHost) {
        const nextHost = room.players.values().next().value;
        if (nextHost) nextHost.isHost = true;
      }

      if (room.phase === "in-game") {
        evaluateGameStatus(room);
      }
      emitRoom(code);
    });
  });
});

server.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Orbital Sentinel server running on http://localhost:${PORT}`);
});
